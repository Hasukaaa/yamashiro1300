// 山代温泉1300年 Instagramギャラリー - メインJavaScript

// 投稿データ（インライン化 - CORS問題を回避）
const POSTS_DATA = [{"id":1,"title":"瑠璃光 - 源泉かけ流しの贅沢","description":"開湯1300年の歴史を持つ山代温泉の名旅館「瑠璃光」。源泉100%のかけ流し温泉で心身ともに癒されるひとときを。","category":"旅館","tags":["旅館","源泉かけ流し","高級宿"],"imageUrl":"https://images.unsplash.com/photo-1564501049412-61c2a3083791?w=800&h=800&fit=crop&q=80","instagramUrl":"https://www.instagram.com/p/DNHmzzZTAg3/","postId":"DNHmzzZTAg3"},{"id":2,"title":"たちばな四季亭 - 四季を彩る料亭旅館","description":"輪島塗と九谷焼に彩られた上質な客室で、旬の加賀料理を堪能。山代温泉の風情を存分に味わえる料亭旅館。","category":"旅館","tags":["旅館","料亭","加賀料理"],"imageUrl":"https://images.unsplash.com/photo-1551882547-ff40c63fe5fa?w=800&h=800&fit=crop&q=80","instagramUrl":"https://www.instagram.com/p/DNKI6YcTBWe/","postId":"DNKI6YcTBWe"},{"id":3,"title":"古総湯 - 明治時代の湯治場を再現","description":"明治時代の総湯を忠実に復元した共同浴場。ステンドグラスの輝きと歴史の重みを感じる特別な空間。","category":"温泉施設","tags":["温泉","古総湯","歴史"],"imageUrl":"https://images.unsplash.com/photo-1583416750470-965b2707b355?w=800&h=800&fit=crop&q=80","instagramUrl":"https://www.instagram.com/p/DNM8oAIT0qr/","postId":"DNM8oAIT0qr"},{"id":4,"title":"割烹もりもと - 北陸の旬を味わう","description":"新鮮な日本海の幸と加賀野菜を使った本格割烹料理。ふぐ料理や蟹料理が自慢の名店。","category":"飲食店","tags":["飲食店","割烹","ふぐ"],"imageUrl":"https://images.unsplash.com/photo-1579584425555-c3ce17fd4351?w=800&h=800&fit=crop&q=80","instagramUrl":"https://www.instagram.com/p/DNP7kKDT6FU/","postId":"DNP7kKDT6FU"},{"id":5,"title":"九谷焼窯元 - 伝統の技を間近で","description":"約360年の歴史を持つ九谷焼の窯元。職人の技を見学し、絵付け体験もできる貴重な機会。","category":"文化・芸術","tags":["九谷焼","伝統工芸","体験"],"imageUrl":"https://images.unsplash.com/photo-1578749556568-bc2c40e68b61?w=800&h=800&fit=crop&q=80","instagramUrl":"https://www.instagram.com/p/DNSassmz1JP/","postId":"DNSassmz1JP"},{"id":6,"title":"山代温泉総湯 - 地元に愛される共同浴場","description":"100%源泉かけ流しの共同浴場。地元の人々と観光客が交流する温泉文化の拠点。","category":"温泉施設","tags":["温泉","総湯","共同浴場"],"imageUrl":"https://images.unsplash.com/photo-1540555700478-4be289fbecef?w=800&h=800&fit=crop&q=80","instagramUrl":"https://www.instagram.com/p/DNUuaszzfcL/","postId":"DNUuaszzfcL"},{"id":7,"title":"温泉街の夜景 - 幻想的な灯り","description":"夕暮れ時の温泉街に灯る優しい明かり。石畳の道を歩けば、時代を超えた風情が心に染みる。","category":"観光スポット","tags":["夜景","温泉街","散策"],"imageUrl":"https://images.unsplash.com/photo-1480796927426-f609979314bd?w=800&h=800&fit=crop&q=80","instagramUrl":"https://www.instagram.com/p/DNXNVEazYeV/","postId":"DNXNVEazYeV"},{"id":8,"title":"のどぐろ料理 - 北陸の高級魚","description":"脂ののった極上のどぐろを贅沢に。塩焼き、煮付け、お刺身など、様々な調理法で味わう至福。","category":"グルメ","tags":["グルメ","のどぐろ","日本海"],"imageUrl":"https://images.unsplash.com/photo-1580822184713-fc5400e7fe10?w=800&h=800&fit=crop&q=80","instagramUrl":"https://www.instagram.com/p/DNaBLQ4z59N/","postId":"DNaBLQ4z59N"},{"id":9,"title":"女生水地蔵尊祭 - 夏の風物詩","description":"山代温泉の守り神を祀る伝統的な夏祭り。屋台やビアガーデン、花火で賑わう一大イベント。","category":"イベント","tags":["イベント","祭り","夏"],"imageUrl":"https://images.unsplash.com/photo-1533174072545-7a4b6ad7a6c3?w=800&h=800&fit=crop&q=80","instagramUrl":"https://www.instagram.com/p/DNcF34KTQe0/","postId":"DNcF34KTQe0"},{"id":10,"title":"加賀料理 - 季節の懐石","description":"日本海の幸と加賀野菜を活かした繊細な懐石料理。目でも舌でも楽しめる芸術的な一皿。","category":"グルメ","tags":["グルメ","懐石料理","加賀料理"],"imageUrl":"https://images.unsplash.com/photo-1580822184713-fc5400e7fe10?w=800&h=800&fit=crop&q=80","instagramUrl":"https://www.instagram.com/p/DNe7Vs0zkEb/","postId":"DNe7Vs0zkEb"},{"id":11,"title":"源泉公園 - 温泉の源を感じる","description":"山代温泉の源泉が湧き出る公園。足湯も楽しめ、散策の休憩にぴったりの癒しスポット。","category":"観光スポット","tags":["観光","足湯","源泉"],"imageUrl":"https://images.unsplash.com/photo-1582719188393-bb71ca45dbb9?w=800&h=800&fit=crop&q=80","instagramUrl":"https://www.instagram.com/p/DNiH4ZYzizO/","postId":"DNiH4ZYzizO"},{"id":12,"title":"稲妻太鼓 - 加賀の伝統芸能","description":"迫力満点の和太鼓パフォーマンス。体験教室も開催され、伝統文化を身近に感じられる。","category":"イベント","tags":["イベント","和太鼓","伝統文化"],"imageUrl":"https://images.unsplash.com/photo-1528838378372-87f0ab01c31e?w=800&h=800&fit=crop&q=80","instagramUrl":"https://www.instagram.com/p/DNj9OW3zBNK/","postId":"DNj9OW3zBNK"},{"id":13,"title":"山下家 - 創業200年の老舗旅館","description":"1805年創業の歴史ある旅館。開湯1300年の湯と伝統のおもてなしで、特別な時間を演出。","category":"旅館","tags":["旅館","老舗","歴史"],"imageUrl":"https://images.unsplash.com/photo-1566073771259-6a8506099945?w=800&h=800&fit=crop&q=80","instagramUrl":"https://www.instagram.com/p/DNm5JyYT_mD/","postId":"DNm5JyYT_mD"},{"id":14,"title":"炭焼チキン堂 - こだわりの炭火焼","description":"炭火でじっくり焼き上げる絶品焼き鳥。山代温泉散策の〆に立ち寄りたい人気店。","category":"飲食店","tags":["飲食店","焼き鳥","居酒屋"],"imageUrl":"https://images.unsplash.com/photo-1529006557810-274b9b2fc783?w=800&h=800&fit=crop&q=80","instagramUrl":"https://www.instagram.com/p/DNpZlb6z3cA/","postId":"DNpZlb6z3cA"},{"id":15,"title":"九谷焼絵付け体験 - 自分だけの作品を","description":"伝統的な九谷焼の絵付けに挑戦。職人の指導のもと、世界に一つだけの器を作る喜び。","category":"文化・芸術","tags":["九谷焼","体験","工芸"],"imageUrl":"https://images.unsplash.com/photo-1611419010196-a491d75e3532?w=800&h=800&fit=crop&q=80","instagramUrl":"https://www.instagram.com/p/DNrdy2CZlQk/","postId":"DNrdy2CZlQk"},{"id":16,"title":"温泉まんじゅう - 定番のお土産","description":"ほかほかの温泉まんじゅうは山代温泉の定番おやつ。散策しながら食べ歩きも楽しい。","category":"お土産","tags":["お土産","和菓子","食べ歩き"],"imageUrl":"https://images.unsplash.com/photo-1564834724105-918b73d1b9e0?w=800&h=800&fit=crop&q=80","instagramUrl":"https://www.instagram.com/p/DNucdQOZq3F/","postId":"DNucdQOZq3F"},{"id":17,"title":"薬王院温泉寺 - 静寂の中の祈り","description":"山代温泉発祥の地とされる古刹。緑豊かな境内で心静かに参拝し、心身を清める。","category":"観光スポット","tags":["観光","寺院","歴史"],"imageUrl":"https://images.unsplash.com/photo-1528360983277-13d401cdc186?w=800&h=800&fit=crop&q=80","instagramUrl":"https://www.instagram.com/p/DNw5sgoZiZq/","postId":"DNw5sgoZiZq"},{"id":18,"title":"あらや滔々庵 - モダンと伝統の融合","description":"現代的なデザインと伝統のおもてなしが調和した上質な旅館。洗練された空間で極上の時を。","category":"旅館","tags":["旅館","モダン","高級"],"imageUrl":"https://images.unsplash.com/photo-1591088398332-8a7791972843?w=800&h=800&fit=crop&q=80","instagramUrl":"https://www.instagram.com/p/DNzblXxZqmA/","postId":"DNzblXxZqmA"},{"id":19,"title":"加賀地酒 - 地元の銘酒を堪能","description":"加賀の名水で仕込んだ地酒の数々。温泉と共に楽しむ日本酒は格別の味わい。","category":"グルメ","tags":["グルメ","日本酒","地酒"],"imageUrl":"https://images.unsplash.com/photo-1545569341-9eb8b30979d9?w=800&h=800&fit=crop&q=80","instagramUrl":"https://www.instagram.com/p/DN135HU5pAy/","postId":"DN135HU5pAy"},{"id":20,"title":"カニ料理 - 冬の味覚の王様","description":"ズワイガニ、加能ガニなど、冬の日本海を代表する味覚。プリプリの身を贅沢に味わう。","category":"グルメ","tags":["グルメ","カニ","冬の味覚"],"imageUrl":"https://images.unsplash.com/photo-1535140728325-a4d3707eee61?w=800&h=800&fit=crop&q=80","instagramUrl":"https://www.instagram.com/p/DN4affFE2Rv/","postId":"DN4affFE2Rv"},{"id":21,"title":"はづちを楽堂 - カフェで一息","description":"温泉街の隠れ家的カフェ。こだわりのコーヒーとスイーツで散策の疲れを癒す。","category":"飲食店","tags":["飲食店","カフェ","スイーツ"],"imageUrl":"https://images.unsplash.com/photo-1559305616-3f99cd43e353?w=800&h=800&fit=crop&q=80","instagramUrl":"https://www.instagram.com/p/DN72FJ6E3Px/","postId":"DN72FJ6E3Px"},{"id":22,"title":"花火大会 - 夏の夜空を彩る","description":"温泉街を照らす華やかな花火。浴衣姿で楽しむ夏の風物詩に心躍る。","category":"イベント","tags":["イベント","花火","夏祭り"],"imageUrl":"https://images.unsplash.com/photo-1470229722913-7c0e2dbbafd3?w=800&h=800&fit=crop&q=80","instagramUrl":"https://www.instagram.com/p/DN9tQk-E9mm/","postId":"DN9tQk-E9mm"},{"id":23,"title":"山城謹製 - 地元の特産品","description":"山代温泉ならではのオリジナル商品。伝統とモダンが融合したこだわりの逸品。","category":"お土産","tags":["お土産","特産品","工芸品"],"imageUrl":"https://images.unsplash.com/photo-1513885535751-8b9238bd345a?w=800&h=800&fit=crop&q=80","instagramUrl":"https://www.instagram.com/p/DOASwNNk73S/","postId":"DOASwNNk73S"},{"id":24,"title":"白山菖蒲亭 - 四季折々の庭園美","description":"美しい日本庭園に囲まれた風雅な旅館。季節ごとに表情を変える景色が心を和ませる。","category":"旅館","tags":["旅館","庭園","四季"],"imageUrl":"https://images.unsplash.com/photo-1540959733332-eab4deabeeaf?w=800&h=800&fit=crop&q=80","instagramUrl":"https://www.instagram.com/p/DOFbh27k97K/","postId":"DOFbh27k97K"},{"id":25,"title":"温泉街散策 - 石畳の風情","description":"情緒あふれる石畳の通りをゆったり散策。レトロな建物や老舗が並ぶ風景に癒される。","category":"観光スポット","tags":["観光","散策","温泉街"],"imageUrl":"https://images.unsplash.com/photo-1478436127897-769e1b3f0f36?w=800&h=800&fit=crop&q=80","instagramUrl":"https://www.instagram.com/p/DSSHIrkE5l0/","postId":"DSSHIrkE5l0"},{"id":26,"title":"葉渡莉 - 露天風呂付き客室","description":"プライベート空間で楽しむ源泉かけ流しの露天風呂。贅沢な時間を独り占め。","category":"旅館","tags":["旅館","露天風呂","高級"],"imageUrl":"https://images.unsplash.com/photo-1584132905271-512b0d8b8f13?w=800&h=800&fit=crop&q=80","instagramUrl":"https://www.instagram.com/p/DST1fqMk1pg/","postId":"DST1fqMk1pg"},{"id":27,"title":"九谷焼ギャラリー - 色彩の美","description":"華やかな五彩に彩られた九谷焼の数々を展示。伝統美術の粋を堪能できる空間。","category":"文化・芸術","tags":["九谷焼","ギャラリー","芸術"],"imageUrl":"https://images.unsplash.com/photo-1561214115-f2f134cc4912?w=800&h=800&fit=crop&q=80","instagramUrl":"https://www.instagram.com/p/DSX8Okwk4vg/","postId":"DSX8Okwk4vg"},{"id":28,"title":"炭焼チキン堂 - マスターの技","description":"備長炭でじっくり焼き上げる絶品焼き鳥。独自のスタイルを貫くカッコいい大人の店。","category":"飲食店","tags":["飲食店","焼き鳥","炭火焼"],"imageUrl":"https://images.unsplash.com/photo-1555939594-58d7cb561ad1?w=800&h=800&fit=crop&q=80","instagramUrl":"https://www.instagram.com/p/DSZR9adE8XV/","postId":"DSZR9adE8XV"},{"id":29,"title":"界 加賀 - 星野リゾートの温泉旅館","description":"伝統工芸と現代デザインが融合したラグジュアリー空間。上質なサービスで心満たされる滞在。","category":"旅館","tags":["旅館","星野リゾート","ラグジュアリー"],"imageUrl":"https://images.unsplash.com/photo-1596178065887-1198b6148b2b?w=800&h=800&fit=crop&q=80","instagramUrl":"https://www.instagram.com/p/DSbpWsCEw59/","postId":"DSbpWsCEw59"},{"id":30,"title":"加賀野菜 - 伝統の味わい","description":"加賀太きゅうり、金時草など、地域に根差した伝統野菜。鮮やかな色と豊かな味が料理を彩る。","category":"グルメ","tags":["グルメ","加賀野菜","郷土料理"],"imageUrl":"https://images.unsplash.com/photo-1540420773420-3366772f4999?w=800&h=800&fit=crop&q=80","instagramUrl":"https://www.instagram.com/p/DSeNBBNk_Uv/","postId":"DSeNBBNk_Uv"},{"id":31,"title":"温泉の朝 - 静寂の時間","description":"朝もやに包まれた温泉街。静かな朝の散歩で心身をリフレッシュする至福の時間。","category":"観光スポット","tags":["観光","朝","散策"],"imageUrl":"https://images.unsplash.com/photo-1551882547-ff40c63fe5fa?w=800&h=800&fit=crop&q=80","instagramUrl":"https://www.instagram.com/p/DShEx7kEwGy/","postId":"DShEx7kEwGy"},{"id":32,"title":"お茶屋文化 - 芸妓の舞","description":"加賀の伝統芸能を継承するお茶屋。優雅な芸妓の舞と三味線の音色に酔いしれる。","category":"文化・芸術","tags":["文化","芸妓","伝統"],"imageUrl":"https://images.unsplash.com/photo-1528360983277-13d401cdc186?w=800&h=800&fit=crop&q=80","instagramUrl":"https://www.instagram.com/p/DSjPVK6kwyg/","postId":"DSjPVK6kwyg"},{"id":33,"title":"足湯カフェ - 温泉街の癒し","description":"足湯に浸かりながらカフェを楽しむ新しいスタイル。散策の休憩にぴったりのスポット。","category":"観光スポット","tags":["観光","足湯","カフェ"],"imageUrl":"https://images.unsplash.com/photo-1552566626-52f8b828add9?w=800&h=800&fit=crop&q=80","instagramUrl":"https://www.instagram.com/p/DSlqXADkwTP/","postId":"DSlqXADkwTP"},{"id":34,"title":"たちばな四季亭 - 料理人の誇り","description":"白衣に身を包んだ料理人たちが腕を振るう懐石料理。春夏秋冬、どの季節もおすすめの絶品。","category":"飲食店","tags":["飲食店","懐石料理","料亭"],"imageUrl":"https://images.unsplash.com/photo-1590846406792-0adc7f938f1d?w=800&h=800&fit=crop&q=80","instagramUrl":"https://www.instagram.com/p/DSpVK61k1u7/","postId":"DSpVK61k1u7"},{"id":35,"title":"紅葉の山代温泉 - 秋の彩り","description":"秋になると温泉街を鮮やかに染める紅葉。赤や黄色に色づいた木々が温泉情緒を一層深める。","category":"観光スポット","tags":["観光","紅葉","秋"],"imageUrl":"https://images.unsplash.com/photo-1476514525535-07fb3b4ae5f1?w=800&h=800&fit=crop&q=80","instagramUrl":"https://www.instagram.com/p/DSrRmFBE5mu/","postId":"DSrRmFBE5mu"},{"id":36,"title":"九谷焼ショップ - お気に入りを探す","description":"色とりどりの九谷焼が並ぶショップ。日常使いから特別な贈り物まで、幅広いラインナップ。","category":"お土産","tags":["お土産","九谷焼","ショッピング"],"imageUrl":"https://images.unsplash.com/photo-1555982105-d25af4182e4e?w=800&h=800&fit=crop&q=80","instagramUrl":"https://www.instagram.com/p/DStowQoE7JG/","postId":"DStowQoE7JG"},{"id":37,"title":"雪の温泉街 - 冬の風情","description":"雪化粧した温泉街は格別の美しさ。静かに降る雪を眺めながらの湯浴みは至福のひととき。","category":"観光スポット","tags":["観光","雪景色","冬"],"imageUrl":"https://images.unsplash.com/photo-1483347756197-71ef80e95f73?w=800&h=800&fit=crop&q=80","instagramUrl":"https://www.instagram.com/p/DSwyb72E22w/","postId":"DSwyb72E22w"},{"id":38,"title":"おしゃれ浴衣 - 温泉街を彩る","description":"旅館で選べるカラフルな浴衣。お気に入りの一着で温泉街を歩けば、旅の楽しさ倍増。","category":"文化・芸術","tags":["浴衣","温泉","ファッション"],"imageUrl":"https://images.unsplash.com/photo-1583416750470-965b2707b355?w=800&h=800&fit=crop&q=80","instagramUrl":"https://www.instagram.com/p/DS0T8a6k1Xx/","postId":"DS0T8a6k1Xx"},{"id":39,"title":"地ビール - 加賀の恵み","description":"地元の水と素材で醸造された加賀のクラフトビール。温泉上がりの一杯は格別。","category":"グルメ","tags":["グルメ","ビール","地ビール"],"imageUrl":"https://images.unsplash.com/photo-1608270586620-248524c67de9?w=800&h=800&fit=crop&q=80","instagramUrl":"https://www.instagram.com/p/DS13utIExi7/","postId":"DS13utIExi7"},{"id":40,"title":"温泉街のアート - 現代と伝統の対話","description":"温泉街の各所に点在するアート作品。伝統的な町並みとモダンアートの共演が新しい魅力を生む。","category":"文化・芸術","tags":["アート","現代美術","温泉街"],"imageUrl":"https://images.unsplash.com/photo-1547826039-bfc35e0f1ea8?w=800&h=800&fit=crop&q=80","instagramUrl":"https://www.instagram.com/p/DS4BA3Yk-8J/","postId":"DS4BA3Yk-8J"},{"id":41,"title":"カップルプラン - 二人だけの時間","description":"カップル向けの特別プラン。露天風呂付き客室で二人きりの贅沢なひとときを過ごす。","category":"旅館","tags":["旅館","カップル","プラン"],"imageUrl":"https://images.unsplash.com/photo-1566073771259-6a8506099945?w=800&h=800&fit=crop&q=80","instagramUrl":"https://www.instagram.com/p/DS79SGtE9Wc/","postId":"DS79SGtE9Wc"},{"id":42,"title":"やきとり家 - 地元で愛される味","description":"地元の人々に長年愛される焼き鳥の名店。こだわりのタレと炭火の香りが食欲をそそる。","category":"飲食店","tags":["飲食店","焼き鳥","地元"],"imageUrl":"https://images.unsplash.com/photo-1532634922-8fe0b757fb13?w=800&h=800&fit=crop&q=80","instagramUrl":"https://www.instagram.com/p/DS-OwbNE2O4/","postId":"DS-OwbNE2O4"},{"id":43,"title":"温泉街の植物 - 緑の癒し","description":"温泉街のあちこちで見かける植物たち。毎朝の水やりと日光浴で、お客様をお迎えする準備。","category":"観光スポット","tags":["観光","植物","癒し"],"imageUrl":"https://images.unsplash.com/photo-1466781783364-36c955e42a7f?w=800&h=800&fit=crop&q=80","instagramUrl":"https://www.instagram.com/p/DS_3-OsE9sg/","postId":"DS_3-OsE9sg"},{"id":44,"title":"源泉瑠璃光 - 山代の名湯","description":"源泉瑠璃光と呼ばれる山代温泉の源泉から名を受けた瑠璃光。開湯1300年の温泉で癒しのひととき。","category":"温泉施設","tags":["温泉","源泉","瑠璃光"],"imageUrl":"https://images.unsplash.com/photo-1540555700478-4be289fbecef?w=800&h=800&fit=crop&q=80","instagramUrl":"https://www.instagram.com/p/DTCy52YEylf/","postId":"DTCy52YEylf"},{"id":45,"title":"うららん - 温泉郷の魅力体験","description":"加賀温泉郷の魅力を体験できる各種プログラム。文化体験から自然散策まで充実の内容。","category":"イベント","tags":["イベント","体験","うららん"],"imageUrl":"https://images.unsplash.com/photo-1504805572947-34fad45aed93?w=800&h=800&fit=crop&q=80","instagramUrl":"https://www.instagram.com/p/DTE58pTEySt/","postId":"DTE58pTEySt"},{"id":46,"title":"温泉街の猫 - 癒しの住人","description":"温泉街を気ままに歩く猫たち。人懐っこい姿に心が和み、写真撮影も楽しめる。","category":"観光スポット","tags":["観光","猫","癒し"],"imageUrl":"https://images.unsplash.com/photo-1543852786-1cf6624b9987?w=800&h=800&fit=crop&q=80","instagramUrl":"https://www.instagram.com/p/DTIIx37kw1r/","postId":"DTIIx37kw1r"},{"id":47,"title":"温泉卵 - シンプルな美味しさ","description":"温泉の熱で作られたとろ〜り温泉卵。シンプルながら温泉地ならではの味わい深い一品。","category":"グルメ","tags":["グルメ","温泉卵","名物"],"imageUrl":"https://images.unsplash.com/photo-1582169296194-e4d644c48063?w=800&h=800&fit=crop&q=80","instagramUrl":"https://www.instagram.com/p/DTKuKPxE9wK/","postId":"DTKuKPxE9wK"}];

// グローバル変数
let allPosts = [];
let currentCategory = 'すべて';

// DOMが読み込まれたら実行
document.addEventListener('DOMContentLoaded', () => {
    console.log('山代温泉1300年ギャラリーを初期化中...');
    
    try {
        // インラインデータを使用
        allPosts = POSTS_DATA;
        console.log(`${allPosts.length}件の投稿を読み込みました`);
        
        // ローディング表示を非表示
        document.getElementById('loading').style.display = 'none';
        
        // ギャラリーをレンダリング
        renderGallery();
        
        // 横スクロールアニメーションを初期化
        initHorizontalScroll();
        
        // フィルターボタンのイベントリスナーを設定
        setupFilters();
        
        // モーダルのイベントリスナーを設定
        setupModal();
        
        console.log('ギャラリーの初期化が完了しました！');
    } catch (error) {
        console.error('ギャラリーの初期化に失敗しました:', error);
        showError('ギャラリーの初期化に失敗しました。ページを再読み込みしてください。');
    }
});

/**
 * ギャラリーをレンダリング
 */
function renderGallery(filteredPosts = allPosts) {
    const container = document.getElementById('galleryContainer');
    container.innerHTML = '';
    
    if (filteredPosts.length === 0) {
        container.innerHTML = `
            <div style="width: 100%; text-align: center; padding: 4rem;">
                <i class="fas fa-search" style="font-size: 4rem; color: var(--primary); opacity: 0.3; margin-bottom: 1rem;"></i>
                <p style="font-size: 1.2rem; color: #666;">該当する投稿が見つかりませんでした</p>
            </div>
        `;
        return;
    }
    
    filteredPosts.forEach((post, index) => {
        const item = createGalleryItem(post, index);
        container.appendChild(item);
    });
    
    console.log(`${filteredPosts.length}件の投稿を表示しました`);
    
    // 横スクロールアニメーションを再初期化
    if (window.horizontalScrollTrigger) {
        window.horizontalScrollTrigger.kill();
    }
    initHorizontalScroll();
}

/**
 * ギャラリーアイテムを作成
 */
function createGalleryItem(post, index) {
    const item = document.createElement('div');
    item.className = 'gallery-item';
    item.dataset.category = post.category;
    item.dataset.postId = post.id;
    
    // 遅延読み込み用の属性
    item.style.opacity = '0';
    item.style.transform = 'translateY(30px)';
    
    item.innerHTML = `
        <img class="gallery-image" 
             src="${post.imageUrl}" 
             alt="${post.title}"
             loading="lazy"
             onerror="this.src='https://images.unsplash.com/photo-1551882547-ff40c63fe5fa?w=800&h=800&fit=crop&q=80'">
        <div class="gallery-info">
            <div>
                <span class="gallery-category">${getCategoryIcon(post.category)} ${post.category}</span>
                <h3 class="gallery-title">${post.title}</h3>
                <p class="gallery-description">${post.description}</p>
            </div>
        </div>
    `;
    
    // クリックイベント
    item.addEventListener('click', () => openModal(post));
    
    // アニメーション（遅延）
    setTimeout(() => {
        item.style.transition = 'all 0.6s ease';
        item.style.opacity = '1';
        item.style.transform = 'translateY(0)';
    }, index * 50);
    
    return item;
}

/**
 * カテゴリーに対応するアイコンを取得
 */
function getCategoryIcon(category) {
    const icons = {
        '旅館': '🏨',
        '飲食店': '🍜',
        '温泉施設': '♨️',
        '文化・芸術': '🎨',
        '観光スポット': '🌸',
        'イベント': '🎉',
        'グルメ': '🍱',
        'お土産': '🛍️'
    };
    return icons[category] || '📍';
}

/**
 * 横スクロールアニメーションを初期化（GSAP ScrollTrigger）
 */
function initHorizontalScroll() {
    // デスクトップのみで横スクロールを有効化
    if (window.innerWidth < 1024) {
        console.log('モバイル/タブレット: 横スクロール無効');
        return;
    }
    
    gsap.registerPlugin(ScrollTrigger);
    
    const wrapper = document.getElementById('galleryWrapper');
    const container = document.getElementById('galleryContainer');
    
    if (!container.children.length) {
        console.log('ギャラリーアイテムがありません');
        return;
    }
    
    const scrollWidth = container.scrollWidth - window.innerWidth;
    
    if (scrollWidth <= 0) {
        console.log('スクロール幅が不十分です');
        return;
    }
    
    window.horizontalScrollTrigger = gsap.to(container, {
        x: -scrollWidth,
        ease: 'none',
        scrollTrigger: {
            trigger: wrapper,
            start: 'top top',
            end: () => `+=${scrollWidth}`,
            scrub: 1,
            pin: true,
            anticipatePin: 1,
            invalidateOnRefresh: true
        }
    });
    
    console.log('横スクロールアニメーションを初期化しました');
}

/**
 * フィルターボタンの設定
 */
function setupFilters() {
    const filterButtons = document.querySelectorAll('.filter-btn');
    
    filterButtons.forEach(button => {
        button.addEventListener('click', () => {
            const category = button.dataset.category;
            
            // アクティブ状態を更新
            filterButtons.forEach(btn => btn.classList.remove('active'));
            button.classList.add('active');
            
            // カテゴリーを更新
            currentCategory = category;
            
            // フィルタリングして表示
            filterGallery(category);
            
            console.log(`フィルター適用: ${category}`);
        });
    });
}

/**
 * ギャラリーをフィルタリング
 */
function filterGallery(category) {
    let filteredPosts = allPosts;
    
    if (category !== 'すべて') {
        filteredPosts = allPosts.filter(post => post.category === category);
    }
    
    renderGallery(filteredPosts);
    
    // スクロール位置をリセット
    window.scrollTo({ top: 0, behavior: 'smooth' });
}

/**
 * モーダルの設定
 */
function setupModal() {
    const modal = document.getElementById('modal');
    const modalClose = document.getElementById('modalClose');
    const modalShare = document.getElementById('modalShare');
    
    // 閉じるボタン
    modalClose.addEventListener('click', closeModal);
    
    // モーダル背景クリックで閉じる
    modal.addEventListener('click', (e) => {
        if (e.target === modal) {
            closeModal();
        }
    });
    
    // ESCキーで閉じる
    document.addEventListener('keydown', (e) => {
        if (e.key === 'Escape' && modal.classList.contains('active')) {
            closeModal();
        }
    });
    
    // シェアボタン
    modalShare.addEventListener('click', sharePost);
}

/**
 * モーダルを開く
 */
function openModal(post) {
    const modal = document.getElementById('modal');
    
    // モーダル要素を更新
    document.getElementById('modalImage').src = post.imageUrl;
    document.getElementById('modalImage').alt = post.title;
    document.getElementById('modalCategory').textContent = `${getCategoryIcon(post.category)} ${post.category}`;
    document.getElementById('modalTitle').textContent = post.title;
    document.getElementById('modalDescription').textContent = post.description;
    document.getElementById('modalInstagramLink').href = post.instagramUrl;
    
    // タグを表示
    const tagsContainer = document.getElementById('modalTags');
    tagsContainer.innerHTML = '';
    post.tags.forEach(tag => {
        const tagElement = document.createElement('span');
        tagElement.className = 'modal-tag';
        tagElement.textContent = `#${tag}`;
        tagsContainer.appendChild(tagElement);
    });
    
    // モーダルを表示
    modal.classList.add('active');
    document.body.style.overflow = 'hidden';
    
    // シェアボタンにデータを保存
    document.getElementById('modalShare').dataset.postTitle = post.title;
    document.getElementById('modalShare').dataset.postUrl = post.instagramUrl;
    
    console.log(`モーダルを開きました: ${post.title}`);
}

/**
 * モーダルを閉じる
 */
function closeModal() {
    const modal = document.getElementById('modal');
    modal.classList.remove('active');
    document.body.style.overflow = '';
    console.log('モーダルを閉じました');
}

/**
 * 投稿をシェア
 */
async function sharePost() {
    const shareBtn = document.getElementById('modalShare');
    const title = shareBtn.dataset.postTitle;
    const url = shareBtn.dataset.postUrl;
    
    // Web Share API をサポートしているか確認
    if (navigator.share) {
        try {
            await navigator.share({
                title: `${title} - 山代温泉開湯1300年`,
                text: `山代温泉の魅力をチェック！`,
                url: url
            });
            console.log('シェアに成功しました');
        } catch (error) {
            if (error.name !== 'AbortError') {
                console.error('シェアエラー:', error);
                fallbackShare(url);
            }
        }
    } else {
        // Web Share API が使えない場合はフォールバック
        fallbackShare(url);
    }
}

/**
 * シェア機能のフォールバック（クリップボードにコピー）
 */
function fallbackShare(url) {
    if (navigator.clipboard) {
        navigator.clipboard.writeText(url).then(() => {
            alert('リンクをクリップボードにコピーしました！');
        }).catch(err => {
            console.error('クリップボードへのコピー失敗:', err);
            prompt('以下のリンクをコピーしてください:', url);
        });
    } else {
        prompt('以下のリンクをコピーしてください:', url);
    }
}

/**
 * エラー表示
 */
function showError(message) {
    const loading = document.getElementById('loading');
    loading.innerHTML = `
        <div style="color: var(--highlight);">
            <i class="fas fa-exclamation-triangle" style="font-size: 3rem; margin-bottom: 1rem;"></i>
            <p style="font-size: 1.2rem; font-weight: 600;">${message}</p>
        </div>
    `;
}

/**
 * ウィンドウリサイズ時の処理
 */
let resizeTimeout;
window.addEventListener('resize', () => {
    clearTimeout(resizeTimeout);
    resizeTimeout = setTimeout(() => {
        console.log('ウィンドウサイズが変更されました');
        
        // 横スクロールを再初期化
        if (window.horizontalScrollTrigger) {
            window.horizontalScrollTrigger.kill();
        }
        initHorizontalScroll();
    }, 250);
});

console.log('🌸 山代温泉開湯1300年 Instagramギャラリー 🌸');
console.log(`投稿数: ${POSTS_DATA.length}`);
